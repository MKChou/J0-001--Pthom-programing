
enter = input("請輸入你有幾毫升95%的酒精：")

enter = int(enter)

add = int((enter*0.95/0.75)-enter)


print("加",add,"毫升的水就會得到75%的酒精")